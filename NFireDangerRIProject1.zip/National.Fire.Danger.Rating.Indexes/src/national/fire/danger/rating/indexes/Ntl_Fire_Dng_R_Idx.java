/**
 * 
 */
package national.fire.danger.rating.indexes;

/**
 * @author Obed Dominguez 
 * @version 1.1 (Initial code for project one) 
 * @since 2016-02-23 (This package was first added) 
 */
public class Ntl_Fire_Dng_R_Idx {

	/**
	 * Main method for re-engineer the Fortran77 code.		(1)
	 * <p>
	 * Re-engineer of Fortran77 code for national			(2)
	 * fire danger rating indexes.  
	 * <>p>
	 * @param args Beginning the main code. 
	 * @return 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
